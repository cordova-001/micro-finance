<div class="card card-bordered card-preview">
    <div class="card-inner">
            <ul class="nav nav-tabs mt-n3">
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('loan.loan_mgt') }}"><span>  General  </span></a>
                </li>
                {{-- <li class="nav-item">
                    <a class="nav-link"  href="{{ route('approved_loans') }}"><span>  SMS  </span></a>
                </li> --}}
                <li class="nav-item">
                    <a class="nav-link"  href="{{ route('rejected_loans') }}"><span> Email Template  </span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link"  href="{{ route('disbursed_loans') }}"><span> SMS Template </span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link"  href="{{ route('disbursed_loans') }}"><span> System  </span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link"  href="{{ route('disbursed_loans') }}"><span> Company </span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link"  href="{{ route('disbursed_loans') }}"><span> Subscription and Payment </span></a>
                </li>          
                <li class="nav-item">
                    <a class="nav-link"  href="{{ route('disbursed_loans') }}"><span> Financial Accounting </span></a>
                </li>      

            </ul>
    </div>